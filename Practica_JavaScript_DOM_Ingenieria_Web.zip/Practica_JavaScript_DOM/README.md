# Práctica guiada: JavaScript, DOM y formularios

**Asignatura:** Ingeniería Web  
**Duración sugerida:** 40 a 45 minutos  
**Requisitos:** VS Code, navegador y opcionalmente Live Server. No requiere XAMPP ni conexión a Internet.

## Propósito
Transformar una página HTML/CSS en una interfaz interactiva usando JavaScript: variables, funciones, arreglos, objetos, eventos, DOM, validación de formularios y contenido dinámico.

## Cómo ejecutarlo
1. Descomprimir el ZIP.
2. Abrir la carpeta `Practica_JavaScript_DOM` en VS Code.
3. Abrir `index.html` con Live Server o directamente en un navegador.
4. Abrir DevTools > Console y Elements para observar los cambios.
5. Editar `js/app.js`, guardar y recargar el navegador si es necesario.

## Recorrido docente (40 minutos)

| Tiempo | Demostración | En el código |
| --- | --- | --- |
| 0–5 min | Identificar HTML, CSS y JavaScript y revisar `<script defer>` | `index.html` |
| 5–12 min | Pulsar “Mostrar saludo” varias veces; cambiar texto y contador | Variables, función y `addEventListener` |
| 12–20 min | Revisar las tarjetas generadas; añadir un tema desde el formulario | Arreglo de objetos, `forEach`, `createElement`, `textContent` |
| 20–32 min | Probar formulario con datos vacíos, correo incorrecto y valores válidos | `submit`, `preventDefault`, validación y `classList` |
| 32–40 min | Agregar varios participantes y limpiar; observar cambios sin recargar | Array `participantes`, `replaceChildren`, `textContent` |

## Retos para los estudiantes
1. Cambiar el mensaje del saludo y mostrar la fecha actual con `new Date().toLocaleDateString('es-EC')`.
2. Agregar un cuarto tema inicial al arreglo `temas`.
3. Evitar agregar un tema con nombre repetido (ignorando mayúsculas y espacios).
4. Exigir que el nombre del participante tenga al menos 5 caracteres.
5. Mostrar un aviso cuando se registren 3 participantes.

## Preguntas de cierre
- ¿Cuál es la diferencia entre modificar HTML manualmente y actualizar el DOM con JavaScript?
- ¿Para qué sirve `evento.preventDefault()` en los formularios de esta práctica?
- ¿Por qué usamos `textContent` en lugar de concatenar texto del usuario dentro de `innerHTML`?
- ¿Qué ocurriría con los participantes si recargamos la página? ¿Por qué?
- ¿Por qué la validación del lado del cliente no es suficiente para proteger una aplicación real?

## Entregable opcional
Repositorio GitHub con el código actualizado, al menos dos mejoras realizadas y un commit descriptivo, por ejemplo `Agregar validaciones y contenido dinamico`.

## Consideración importante
La práctica es **solo frontend**. Los datos no se envían ni se guardan en un servidor; desaparecen al recargar. La expresión regular del correo valida únicamente un formato básico. Una aplicación real debe validar nuevamente en el servidor y aplicar los controles de seguridad correspondientes.
